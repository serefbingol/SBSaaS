-- Bu dosya, varsayılan olarak $POSTGRES_DB üzerinde çalıştırılır.
-- docker-entrypoint içi sıralamada 00-entrypoint.sh'ten SONRA ve 02-schemas'tan ÖNCE gelir.

-- TimescaleDB uzantısı
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- PostGIS uzantısı
CREATE EXTENSION IF NOT EXISTS postgis;

-- pgAgent uzantısı (paket kuruluysa)
-- Bazı dağıtımlarda pgAgent ayrı kurulum gerektirebilir; IF NOT EXISTS hata atmaz.
CREATE EXTENSION IF NOT EXISTS pgagent;

-- Faydalı ek uzantılar (opsiyonel)
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
