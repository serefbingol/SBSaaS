#!/bin/sh
set -e
set -x

# Retry function (max 15 deneme, her seferinde 5sn bekleme)
retry() {
  local n=1
  local max=15
  local delay=5
  until "$@"; do
    if [ $n -lt $max ]; then
      echo "❌ Komut başarısız oldu: '$@'. $n/$max deneme... ${delay}s sonra tekrar denenecek."
      n=$((n+1))
      sleep $delay
    else
      echo "⛔ Komut defalarca denendi ama başarısız oldu: '$@'"
      return 1
    fi
  done
}

echo "⏳ RabbitMQ hazır olana kadar bekleniyor..."
retry nc -z ${RABBITMQ_HOST} ${RABBITMQ_PORT}

echo "⏳ MinIO hazır olana kadar bekleniyor..."
retry nc -z 172.28.0.21 9000

# Önce alias sil (varsa)
mc alias rm local || true

# Alias ayarla
retry mc alias set local http://172.28.0.21:9000 ${MINIO_ROOT_USER} ${MINIO_ROOT_PASSWORD}

# Bucket oluştur (varsa ignore et)
retry mc mb --ignore-existing local/${MINIO_BUCKET}

# AMQP config set
retry mc admin config set local notify_amqp:1 \
    url="amqp://${RABBITMQ_USER}:${RABBITMQ_PASSWORD}@${RABBITMQ_HOST}:${RABBITMQ_PORT}" \
    exchange="minio-exchange" \
    routing_key="file.uploaded" \
    queue="minio-file-events" \
    queue_limit="1000" \
    durable="true"

# Config sonrası restart
retry mc admin service restart local

sleep 5

# Eski event tanımını sil (varsa)
mc event remove local/${MINIO_BUCKET} --force || true

# Yeni event ekle
retry mc event add --ignore-existing local/${MINIO_BUCKET} arn:minio:sqs::1:amqp --event put

echo "✅ MinIO event notifications for RabbitMQ configured successfully."
