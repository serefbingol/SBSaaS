#!/usr/bin/env bash
set -euo pipefail

# Bu script, resmi Postgres entrypoint'inin init aşamasında ($PGDATA boşken) çağrılır.
# Postgres default entrypoint, önce cluster'ı ve $POSTGRES_DB'yi oluşturur,
# sonra /docker-entrypoint-initdb.d içindeki dosyaları alfabetik sırayla çalıştırır.
# Biz bu scripti 00- prefiksiyle kopyaladık ki en önce çalışsın.

# ENV öncelikleri:
# - POSTGRES_DB/POSTGRES_USER varsa onları esas al
# - Yoksa DB_NAME/DB_USER'ı kullan
DB_NAME="${POSTGRES_DB:-${DB_NAME:-sbsdb}}"
DB_USER="${POSTGRES_USER:-${DB_USER:-sbsuser}}"

echo ">>> [00-entrypoint] Target DB: ${DB_NAME} | DB User: ${DB_USER}"

# Not: Resmi entrypoint $POSTGRES_USER ve $POSTGRES_DB'yi zaten oluşturur.
# Burada sadece şema şablonunu doldurup uyguluyoruz.

# Şema dosyasındaki placeholder'ı ENV ile değiştir
sed "s/:DB_USER/${DB_USER}/g" /docker-entrypoint-initdb.d/02-schemas.sql.template \
  > /tmp/02-schemas.sql

# Şemaları uygulama (hata olursa init durur)
psql -v ON_ERROR_STOP=1 --username "${POSTGRES_USER}" --dbname "${DB_NAME}" -f /tmp/02-schemas.sql

echo ">>> [00-entrypoint] Schemas applied on ${DB_NAME}"
